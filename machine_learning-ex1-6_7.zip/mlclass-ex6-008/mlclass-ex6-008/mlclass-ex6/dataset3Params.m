function [C, sigma] = dataset3Params(X, y, Xval, yval)
%EX6PARAMS returns your choice of C and sigma for Part 3 of the exercise
%where you select the optimal (C, sigma) learning parameters to use for SVM
%with RBF kernel
%   [C, sigma] = EX6PARAMS(X, y, Xval, yval) returns your choice of C and 
%   sigma. You should complete this function to return the optimal C and 
%   sigma based on a cross-validation set.
%

% You need to return the following variables correctly.
C = 1;
sigma = 0.3;

% ====================== YOUR CODE HERE ======================
% Instructions: Fill in this function to return the optimal C and sigma
%               learning parameters found using the cross validation set.
%               You can use svmPredict to predict the labels on the cross
%               validation set. For example, 
%                   predictions = svmPredict(model, Xval);
%               will return the predictions on the cross validation set.
%
%  Note: You can compute the prediction error using 
%        mean(double(predictions ~= yval))
%
numTrials=10;
error=zeros(numTrials,numTrials);
C_sav=zeros(numTrials,1);
sigma_sav=zeros(numTrials,1);
C_sav(1)=0.01;
sigma_sav(1)=0.01;

for i=1:length(C_sav)  
    for j=1:length(sigma_sav)       
        model= svmTrain(X, y, C_sav(i), @(x1, x2) gaussianKernel(x1, x2, sigma_sav(j))); 
        predictions = svmPredict(model, Xval);
        error(i,j)=mean(double(predictions ~= yval));
        if j<numTrials
            sigma_sav(j+1)=sigma_sav(j)*3;
        end
    end
    if i<numTrials
        C_sav(i+1)=C_sav(i)*3;
    end
end
[m,ix]=min(error(:));
[I,J] = ind2sub([numTrials,numTrials],ix);


C=C_sav(I);
sigma=sigma_sav(J);
% =========================================================================

end
